function showLoveStory() {
    document.getElementById('loveStory').classList.toggle('hidden');
}
function showGallery() {
    document.getElementById('gallery').classList.toggle('hidden');
}
function showSurprise() {
    document.getElementById('surprise').classList.toggle('hidden');
}